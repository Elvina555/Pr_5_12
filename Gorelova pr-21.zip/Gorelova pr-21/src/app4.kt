import kotlin.math.pow
fun main()
{
    try
    {
        var x = readLine()!!.toDouble()
        when {
            (x<=1)->println(0)
            else->println(1/x+6)
             }
    }
    catch(e: Exception)

    {
        println("введите число")
    }
}