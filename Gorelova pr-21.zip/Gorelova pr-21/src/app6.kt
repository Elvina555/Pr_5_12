import kotlin.math.pow
fun main()
{
    try
    {
        println("Введите x")
        var x = readLine()!!.toInt()
        println("Введите y")
        var y = readLine()!!.toInt()
        println("Введите d")
        var d = readLine()!!.toInt()
        var m=x*y
        when
        {
            (m<d)->println("Голова Феди влезит в форточку")
            else->println("Голова Феди не влезит в форточку")
        }
    }

    catch(e: Exception)

    {
        println("введите число")
    }
}