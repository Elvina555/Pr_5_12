import kotlin.math.pow
fun main()
{
    try
    {
        println("Введите двузначное число")
        var x = readLine()!!.toInt()
        var a=x%10
        var b=x/10
        when {
            (a==3 || b==3 )->println("В числе придсутствует число 3")
            (a==6||b==6)->println("В числе придсутствует число 6")
            (a==9||b==9)->println("В числе придсутствует число 9")
            else->println("В числе не придсутствуют числа 3 или 6 или 9")

        }
    }
    catch(e: Exception)

    {
        println("введите число")
    }
}

