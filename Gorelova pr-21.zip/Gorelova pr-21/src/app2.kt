import kotlin.math.pow
fun main()
{
    try {
        var num = readLine()!!.toInt()
        when {
            (num == 0) -> println("ноль")
            (num == 1) -> println("один")
            (num == 2) -> println("два")
            (num == 3) -> println("три")
            (num == 4) -> println("четыре")
            (num == 5) -> println("пять")
            (num == 6) -> println("шесть")
            (num == 7) -> println("семь")
            (num == 8) -> println("восемь")
            (num == 9) -> println("девять")
            else -> println("введите другое число")
        }
    }
    catch(e: Exception)

    {
        println("введите число")
    }
}