import kotlin.math.pow
fun main()
{
    try
    {
        var num = readLine()!!.toInt()
        when {
            (num >= 0) && (num <= 2) -> println("младенец")
            (num >= 3) && (num <= 11) -> println("ребенок")
            (num >= 12) && (num <= 18) -> println("подросток")
            (num >= 19) && (num <= 50) -> println("взрослый")
            (num >= 51) && (num <= 100) -> println("пожилой")
            else -> print("введите другое число")
        }
    }
    catch(e: Exception)

    {
        println("введите число")
    }
}


