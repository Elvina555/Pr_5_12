import kotlin.math.pow
fun main()
{
    var age= readLine()!!.toDouble()
    age=age.pow(3)
    println("Hello, $age")
}